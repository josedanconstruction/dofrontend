import React, { Component } from 'react';
import File from './file.json';
// import $ from 'jquery';
import './App.css';


var settings = {
  "async": true,
  "crossDomain": true,
  "url": "http://18.221.220.5/login",
  "method": "POST",
  "headers": {
    "cache-control": "no-cache",
    "postman-token": "58f2ab22-f58a-babb-63e9-3d9b3600ff92"
  },
  "data": "{\"name\" : \"admin\", \"password\" : \"password\", \"role\" : \"ADMIN\"}"
}

var trial = new XMLHttpRequest(settings);

console.log(trial);

var invocation = new XMLHttpRequest();
var url = 'http://18.221.220.5/login';
var body = "{\"name\" : \"admin\", \"password\" : \"password\", \"role\" : \"ADMIN\"}";
// var body = '{"name" : "user", "password" : "clave", "role" : "client"}';



function callOtherDomain(){

console.log("first")
  if(invocation)

    {
      console.log('second');
      invocation.open('POST', url, true);
      invocation.setRequestHeader('X-PINGOTHER', 'pingpong');
      invocation.setRequestHeader('cache-control', 'no-cache');
      invocation.setRequestHeader('Content-Type', 'application/xml');
      invocation.withCredentials = true;
      // invocation.onreadystatechange = function() {
      //   console.log('there was an error1');
      //   console.log(xhr.statusText)
      // }
      // invocation.onreadystatechange = handler;
      invocation.send(body);
      invocation.onreadystatechange = function() {
        var responseText = xhr.responseText;
        console.log("aaaaa"+responseText);
        // process the response.
      };
    }
}

var xhr = new XMLHttpRequest();
xhr.open('GET', 'http://google.com/', true);
xhr.withCredentials = true;
xhr.send('query')
xhr.onload = function() {
  var responseText = xhr.responseText;
  console.log("bbbbb"+responseText);
  // process the response.
};
xhr.onerror = function() {
  console.log('there was an error2');
}

var myHeaders= new Headers();

myHeaders = {"content-type": "application/json",
             "cache-control": "no-cache"
            //  "postman-token": "a5311282-4afc-174e-66bc-53028a809a59"
            };

var myInit = {
              //  'method': 'POST',
               'headers': myHeaders,
               'mode': 'cors',
              //  'data': {'name' : 'user', 'password' : 'clave', 'role' : 'client'},
               'cache': 'default'
             };


             myInit = {"async": true,
                      "crossDomain": true,
                      // "url": "http://18.216.57.125/login",
                      // "method": "POST",
                      "headers": {"content-type": "application/json",
                                 "cache-control": "no-cache",
                                 "postman-token": "9f95df87-e8b5-f089-b968-d9862eaad55b"
                                 },
                      "processData": false
                      // "data": "{\"name\" : \"user\", \"password\" : \"clave\", \"role\" : \"client\"}"
                    }

                    var bob

// var crip = fetch('http://18.216.57.125:80/login', myInit).then(function(response) {
//         response.status     //=> number 100–599
//         response.statusText //=> String
//         response.headers    //=> Headers
//         response.url        //=> String
//
//         return response.text()
//       }
//     // .then(response => response.json())
//     // .then(json => callback(null, json)
//   //  .then(console.log('beta')
//   // response => response.text()
//   // console.log(response => {
//   //           console.log(JSON.stringify(response.json()))
//   //           return JSON.stringify(response.json())
//   //
//   //       })
// )
// .then(console.log(response))

console.log(callOtherDomain())

export default class App extends Component {


  //
  // var queryAPIorSomething = {
  //     componentDidMount: function() {
  //     },


    componentDidMount() {


      if ("withCredentials" in new XMLHttpRequest(
        function ()

            {
              console.log('bah');
              var xhr = new XMLHttpRequest();
              xhr.open('GET', 'http://google.com/', true);
              xhr.withCredentials = true;
              xhr.send('query');}

                                                    // {console.log('bob2')}
                //                                         // console.log('good');
                //                                   // ,
                //
                //                           // queryAPIorSomething(){
                //                         //   var myHeaders = new Headers();
                //                          //
                //                         //   console.log(myHeaders);
                //                          //
                //                         //   myHeaders = {"content-type": "application/json",
                //                         //                "cache-control": "no-cache",
                //                         //                "postman-token": "a5311282-4afc-174e-66bc-53028a809a59"
                //                         //               };
                //                          //
                //                         //   var myInit = { method: 'POST',
                //                         //                  headers: myHeaders,
                //                         //                  mode: 'cors',
                //                         //                  data: {'name' : 'user', 'password' : 'clave', 'role' : 'client'},
                //                         //                  cache: 'default'
                //                         //                };
                //                          //
                //                          //
                //                         //  var settings = {"async": true,
                //                         //                   "crossDomain": true,
                //                         //                   // "url": "http://18.216.57.125/login",
                //                         //                   "method": "POST",
                //                         //                   "headers": {"content-type": "application/json",
                //                         //                               "cache-control": "no-cache",
                //                         //                               // "postman-token": "9f95df87-e8b5-f089-b968-d9862eaad55b"
                //                         //                              },
                //                         //                   "processData": false,
                //                         //                   "data": "{\"name\" : \"user\", \"password\" : \"clave\", \"role\" : \"client\"}"
                //                          //
                //                         //                 };
                //
                                        // {
                                              // fetch('http://18.216.57.125:80/client/api?area=boulder&report=master',
                //                                                                                                                       // myInit({"async": true,
                //                                                                                                                       //        "crossDomain": true,
                //                                                                                                                       //        // "url": "http://18.216.57.125/login",
                //                                                                                                                       //        "method": "POST",
                //                                                                                                                       //        "headers": {"content-type": "application/json",
                //                                                                                                                       //                   "cache-control": "no-cache",
                //                                                                                                                       //                   // "postman-token": "9f95df87-e8b5-f089-b968-d9862eaad55b"
                //                                                                                                                       //                   },
                //                                                                                                                       //        "processData": false,
                //                                                                                                                       //        "data": "{\"name\" : \"user\", \"password\" : \"clave\", \"role\" : \"client\"}"
                //                                                                                                                       //      })
                                                                                                                                          //   {
                                                                                                                                          //
                                                                                                                                          //     console.log('OOOOOOOO')
                                                                                                                                          //     var xhr = new XMLHttpRequest();
                                                                                                                                          // }
                //
                //                                                     )
                // }
              )

        )
        {
        }


      }
      // console.log('bob');
      // fetch('flowers.jpg', myInit).then(function(response) {
      //   return response.blob();
      // }).then(function(myBlob) {
      //   var objectURL = URL.createObjectURL(myBlob);
      //   myImage.src = objectURL;
      // });

  //
  //   }
  // }
    // Do something when component is mounted
    // console.log("Mixin fn ran");

      // //
      // // var cases = File.map(function(caseOnPoint){
      // //   return ({caseOnPoint});
      // // })
      // //
      // // console.log({cases})
      // //
      // // this.cases[1].cases = cases;
      //
      // var items = File.map(function (item, index) {
      //   // Any time you construct a list of elements or components,
      //   // you need to set the `key` so React can more easily work
      //   // with the DOM.
      //   var crap = (index+'-positions').toString();
      //   var crack;
      //
      //   console.log(crap+' and '+ this.nextPosition);
      //
      //   if (index===this.nextPosition){
      //     crack='selected';
      //   }
      //
      //   return (<li id={crack} style = {{border: '1px solid black', width: '11em'/*'-moz-fit-content'*/}} key={index}>{item.address.slice(0, 15)}</li>);
      // }, this);





    componentDidUpdate(){
      console.log(this.cases[1].cases);
    }

    render() {

        // var items = File.map(function (item, index) {
        //   // Any time you construct a list of elements or components,
        //   // you need to set the `key` so React can more easily work
        //   // with the DOM.
        //   var crap = (index+'-positions').toString();
        //   var crack;
        //
        //   console.log(crap+' and '+ this.nextPosition);
        //
        //   if (index==this.nextPosition){
        //     crack='selected';
        //   }
        //
        //   return <li id={crack} style = {{border: '1px solid black', width: '11em'/*'-moz-fit-content'*/}} key={index}>{item.address.slice(0, 15)}</li>;
        // }, this);

      // console.log(this.cases[1].cases);

      var cases = File.map(function(caseOnPoint){
        return caseOnPoint;
      })

      console.log({cases})

      this.cases = cases;

      // var blurb=this.cases[1].cases[0];

      console.log(this.cases[1]);
      console.log({File} + 'I was triggered during render')

      return (
        <div>
          <table id="project_id" style={{margin: '45px', border : '5px solid red', height : '475px', width : '1800px'}}>
            <th>CASE</th>
                <tbody>
                  Permit number: <ti>{this.cases[1].number} {this.queryAPIorSomething}</ti><br/>
                  Description: <ti>{this.cases[1].description}</ti><br/>
                  <br/>
                  <br/>
                  Address: <ti>{this.cases[1].address}</ti><br/>
                  <br/>
                  <br/>
                  Category: <ti>{this.cases[1].category}</ti><br/>
                  Sub-category: <ti>{this.cases[1].usesAndscopes}</ti><br/>
                  Value: $<ti>{this.cases[1].subPermitValue}</ti><br/>
                  Application date: <ti>{this.cases[1].applied}</ti><br/>
                  <span>{this.cases[1].approved && <ti>Application approved: {this.cases[1].approved}</ti>}</span>
                  <span>{this.cases[1].approved && <br/>}</span>
                  <span>{this.cases[1].issued && <ti>Permit issued: {this.cases[1].issued}</ti>}</span>
                  <span>{this.cases[1].issued && <br/>}</span>
                  <span>{this.cases[1].newUnits !== 0 && <ti>New units: {this.cases[1].newUnits}</ti>}</span>
                  <span>{this.cases[1].newUnits !== 0 && <br/>}</span>
                  <span>{this.cases[1].reUnits !== 0 && <ti>Remodeled units{this.cases[1].reUnits}</ti>}</span>
                  <span>{this.cases[1].reUnits !== 0 && <br/>}</span>
                  <span>{this.cases[1].affordableUnits !== 0 && <ti>Affordable housing units: {this.cases[1].affordableUnits}</ti>}</span>
                  <span>{this.cases[1].affordableUnits !== 0 && <br/>}</span>
                  <span>{this.cases[1].newSquareFeet !== 0 && <ti>Square feet added: {this.cases[1].newSquareFeet}</ti>}</span>
                  <span>{this.cases[1].newSquareFeet !== 0 && <br/>}</span>
                  <span>{this.cases[1].reSquareFeet !== 0 && <ti>Remodeled sqaure feet: {this.cases[1].reSquareFeet}</ti>}</span>
                  <span>{this.cases[1].reSquareFeet !== 0 && <br/>}</span>
                  {/* <ti>{this.cases[1].primaryFirst}</ti><br/> */}
                  Applicant Name: <ti>{this.cases[1].primaryLast}</ti><br/>
                  <span>{this.cases[1].primaryCompany && <ti>Company: {this.cases[1].primaryCompany}</ti>}</span>
                  <span>{this.cases[1].primaryCompany && <br/>}</span>
                  {/* <ti>{this.cases[1].contractorFirst}</ti><br/> */}
                  {/* <ti>{this.cases[1].contractorLast}</ti><br/> */}
                  {/* <ti>{this.cases[1].contractorCompany}</ti><br/> */}
                  {/* <ti>{this.cases[1].owner1First}</ti><br/> */}
                  Owner: <ti>{this.cases[1].owner1Last}</ti><br/>
                  <span>{this.cases[1].owner1Company && <ti>Company: {this.cases[1].owner1Company}</ti>}</span>
                  <span>{this.cases[1].owner1Company && <br/>}</span>
                  {/* <ti>{this.cases[1].owner2First}</ti><br/> */}
                  {/* <ti>{this.cases[1].owner2Last}</ti><br/> */}
                  {/* <ti>{this.cases[1].owner2Company}</ti><br/> */}
            </tbody>
          </table>
        </div>
      )
    }
}
