import React, { Component } from 'react';
// import ReactDOM from 'react-dom';
import File from './file.json';
import './App.css';

export default class App extends Component{
  // createClass({

    // propTypes: {
    //   // This will log a message on the console if
    //   // items is not defined or if the wrong type
    //   // is supplied.
    //   items: React.PropTypes.array.isRequired,
    //
    //   // This will only log if the type is wrong.
    //   prefix: React.PropTypes.string,
    // },

    // Sane defaults for your component...
    // getDefaultProps: function () {
    //   return {
    //     prefix: 'Hello'
    //   }
    // },

    // getInitialState: function () {
    //
    //   return {
    //     showDefault: false,
    //     firstPosition: 0,
    //     nextPosition: 0
    //   }
    // },
    //
    // componentWillMount: function () {
    //
    //   //  Here you could setState, fetch data from a server or something else...
    //   // this.queryAPIorSomething('localhost:8081/cli', {} , function (data) {
    //   //   this.setState({ data: data });
    //   // }.bind(this));
    // },
    //
    // componentDidMount: function () {
    //
    //   // You now have access to the DOM:
    //   // console.log(ReactDOM.findDOMNode(this).innerHTML);
    //
    //   // ... or to component references:
    //   // console.log(this.refs.foobar.innerHTML);
    // },
    //
    // componentWillUpdate: function () {
    //   console.log('component about to update!');
    // },
    //
    // componentDidUpdate: function () {
    //   console.log('component updated!');
    //   // DOM is available here...
    // },
    //
    // componentWillUnmount: function () {
    //   // Use this to tear down any event listeners
    //   // or do other cleanup before the compoennt is
    //   // destroyed.
    //   console.log('component will unmount!');
    // },
    //
    // shouldComponentUpdate: function () {
    //   // This is called when state/props changed and is
    //   // an opportunity where you can return false if
    //   // you don't want the component to update for
    //   // some reason.
    //   return true;
    // },
    //
    // // toggle: function (e) {
    // //   // Prevent following the link.
    // //   e.preventDefault();
    // //
    // //   // Invert the chosen default.
    // //   // This will trigger an intelligent re-render of the component.
    // //   console.log(ReactDOM.findDOMNode(this).innerHTML);
    // //   console.log(this.props);
    // //
    // //   this.setState({ showDefault: !this.state.showDefault })
    // // },
    //
    //   //
    //   // moveUp: function (e) {
    //   //   // Prevent following the link.
    //   //   e.preventDefault();
    //   //
    //   //   // Invert the chosen default.
    //   //   // This will trigger an intelligent re-render of the component.
    //   //   console.log(ReactDOM.findDOMNode(this).innerHTML);
    //   //   console.log(this.props.items[this.state.firstPosition].number);
    //   //
    //   //   this.setState({ showDefault: !this.state.showDefault, firstPosition: 1 , nextPosition: (this.state.nextPosition + 1) })
    //   // },
    //   //
    //   //
    //   // moveDown: function (e) {
    //   //   // Prevent following the link.
    //   //   e.preventDefault();
    //   //
    //   //   // Invert the chosen default.
    //   //   // This will trigger an intelligent re-render of the component.
    //   //   console.log(ReactDOM.findDOMNode(this).innerHTML);
    //   //   console.log(this.props.number);
    //   //
    //   //   this.setState({ showDefault: !this.state.showDefault, firstPosition: 1, nextPosition: (this.state.nextPosition - 1) })
    //   // },
    //

    // scrum : function(){ ReactDOM.render()
    //   var items = this.props.items.map(function (item, index) {
    //     // Any time you construct a list of elements or components,
    //     // you need to set the `key` so React can more easily work
    //     // with the DOM.
    //     var crap = (index+'-position').toString();
    //     var crack;
    //
    //     console.log(crap+' and '+ this.state.nextPosition);
    //
    //     if (index===this.state.nextPosition){
    //       crack='selected';
    //     }
    //
    //     return <li id={crack} style = {{border: '1px solid black', width: '11em'/*'-moz-fit-content'*/}} key={index}>{item.address.slice(0, 15)}</li>;
    //   }, this);
    //
    //
    //   if (this.props.items[this.state.nextPosition]) {
    //           console.log(this.props.items[this.state.firstPosition].number);
    //   }

      function(){
      return { status: true }

      App.prototype.render = function() {
        return
        <div>
          <span ref="foobar">
            Showing: {!this.state.firstPosition ? 'default': this.props.items[this.state.nextPosition].number} at {!this.state.firstPosition ? 'default': this.props.items[this.state.nextPosition].address} Boulder, Colorado -      Total Project Value is {!this.state.firstPosition ? 'default': this.props.items[this.state.nextPosition].totalValue}

          <table id="project_id" style={{margin: '45px', border : '5px solid red', height : '475px', width : '1800px'}}>
            <th>CASE</th>
                <tbody>
                  Permit number: <ti>{this.props.items[this.state.nextPosition].number}</ti><br/>
                  Description: <ti>{this.props.items[this.state.nextPosition].description}</ti><br/>
                  <br/>
                  <br/>
                  Address: <ti>{this.props.items[this.state.nextPosition].address}</ti><br/>
                  <br/>
                  <br/>
                  Category: <ti>{this.props.items[this.state.nextPosition].category}</ti><br/>
                  Sub-category: <ti>{this.props.items[this.state.nextPosition].usesAndscopes}</ti><br/>
                  Value: $<ti>{this.props.items[this.state.nextPosition].subPermitValue}</ti><br/>
                  Application date: <ti>{this.props.items[this.state.nextPosition].applied}</ti><br/>
                  <span>{this.props.items[this.state.nextPosition].approved && <ti>Application approved: {this.props.items[this.state.nextPosition].approved}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].approved && <br/>}</span>
                  <span>{this.props.items[this.state.nextPosition].issued && <ti>Permit issued: {this.props.items[this.state.nextPosition].issued}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].issued && <br/>}</span>
                  <span>{this.props.items[this.state.nextPosition].newUnits !== 0 && <ti>New units: {this.props.items[this.state.nextPosition].newUnits}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].newUnits !== 0 && <br/>}</span>
                  <span>{this.props.items[this.state.nextPosition].reUnits !== 0 && <ti>Remodeled units{this.props.items[this.state.nextPosition].reUnits}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].reUnits !== 0 && <br/>}</span>
                  <span>{this.props.items[this.state.nextPosition].affordableUnits !== 0 && <ti>Affordable housing units: {this.props.items[this.state.nextPosition].affordableUnits}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].affordableUnits !== 0 && <br/>}</span>
                  <span>{this.props.items[this.state.nextPosition].newSquareFeet !== 0 && <ti>Square feet added: {this.props.items[this.state.nextPosition].newSquareFeet}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].newSquareFeet !== 0 && <br/>}</span>
                  <span>{this.props.items[this.state.nextPosition].reSquareFeet !== 0 && <ti>Remodeled sqaure feet: {this.props.items[this.state.nextPosition].reSquareFeet}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].reSquareFeet !== 0 && <br/>}</span>
                  {/* <ti>{this.props.items[this.state.nextPosition].primaryFirst}</ti><br/> */}
                  Applicant Name: <ti>{this.props.items[this.state.nextPosition].primaryLast}</ti><br/>
                  <span>{this.props.items[this.state.nextPosition].primaryCompany && <ti>Company: {this.props.items[this.state.nextPosition].primaryCompany}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].primaryCompany && <br/>}</span>
                  {/* <ti>{this.props.items[this.state.nextPosition].contractorFirst}</ti><br/> */}
                  {/* <ti>{this.props.items[this.state.nextPosition].contractorLast}</ti><br/> */}
                  {/* <ti>{this.props.items[this.state.nextPosition].contractorCompany}</ti><br/> */}
                  {/* <ti>{this.props.items[this.state.nextPosition].owner1First}</ti><br/> */}
                  Owner: <ti>{this.props.items[this.state.nextPosition].owner1Last}</ti><br/>
                  <span>{this.props.items[this.state.nextPosition].owner1Company && <ti>Company: {this.props.items[this.state.nextPosition].owner1Company}</ti>}</span>
                  <span>{this.props.items[this.state.nextPosition].owner1Company && <br/>}</span>
                  {/* <ti>{this.props.items[this.state.nextPosition].owner2First}</ti><br/> */}
                  {/* <ti>{this.props.items[this.state.nextPosition].owner2Last}</ti><br/> */}
                  {/* <ti>{this.props.items[this.state.nextPosition].owner2Company}</ti><br/> */}
            </tbody>
          </table>
          </span>
          <a style={{margin: '500px'}} href="" onClick={this.moveDown}>Move Up</a>
          <a style={{margin: '25px'}} href="" onClick={this.moveUp}>Move Down</a>
        </div>
      }
    }
  }
  // });
